const express = require('express');
const fs = require('fs');
const path = require('path');
const hbs = require('hbs');
const MySQL = require('./utilsMySQL');

const app = express();
const port = 3000;

/* MIDDLEWARE */
app.use(express.urlencoded({ extended: true })); 
app.use(express.json());

// Detectar si estem al Proxmox (si és pm2)
const isProxmox =
  !!process.env.PM2_HOME ||
  process.env.exec_mode === "cluster_mode" ||
  process.env.exec_mode === "fork_mode";

// Iniciar connexió MySQL
const db = new MySQL();
if (!isProxmox) {
  db.init({
    host: process.env.MYSQL_HOST ?? '127.0.0.1',
    port: Number(process.env.MYSQL_PORT ?? 3306),
    user: process.env.MYSQL_USER ?? 'root',
    password: process.env.MYSQL_PASS ?? '1234.',
    database: process.env.MYSQL_DB ?? 'sakila',
  });
} else {
  db.init({
    host: process.env.MYSQL_HOST ?? '127.0.0.1',
    port: Number(process.env.MYSQL_PORT ?? 3306),
    user: process.env.MYSQL_USER ?? 'super',
    password: process.env.MYSQL_PASS ?? '1234.',
    database: process.env.MYSQL_DB ?? 'sakila',
  });
}

// Static files
app.use(express.static(path.join(__dirname, '../public')));

// Disable cache
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('Surrogate-Control', 'no-store');
  next();
});

// Handlebars setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');
hbs.registerHelper('eq', (a, b) => a == b);
hbs.registerPartials(path.join(__dirname, 'views', 'partials'));

// --- RUTES GET ---

app.get('/', async (req, res) => {
  try {
    const moviesRows = await db.query('SELECT title, release_year, film_id FROM film LIMIT 5');
    const categoriesRows = await db.query('SELECT name FROM category LIMIT 5');
    const moviesJson = db.table_to_json(moviesRows, { title: 'string', release_year: 'number' });
    const categoriesJson = db.table_to_json(categoriesRows, { name: 'string' });
    const commonData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'common.json'), 'utf8'));

    res.render('index', { movies: moviesJson, categories: categoriesJson, common: commonData });
  } catch (err) {
    res.status(500).send('Error consultant la base de dades (Index)');
  }
});

app.get('/movies', async (req, res) => {
  try {
    const rows = await db.query(`
      SELECT f.film_id, f.title, f.release_year, 
      GROUP_CONCAT(a.first_name, ' ', a.last_name SEPARATOR ', ') AS actors
      FROM film f
      LEFT JOIN film_actor fa ON f.film_id = fa.film_id
      LEFT JOIN actor a ON fa.actor_id = a.actor_id
      GROUP BY f.film_id 
      LIMIT 15
    `);
    const moviesJson = db.table_to_json(rows, { title: 'string', release_year: 'number', actors: 'string' });
    const commonData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'common.json'), 'utf8'));
    res.render('movies', { movies: moviesJson, common: commonData });
  } catch (err) {
    res.status(500).send('Error en movies');
  }
});

app.get('/movie', async (req, res) => {
    const id = req.query.id;
    const rows = await db.query('SELECT * FROM film WHERE film_id = ?', [id]);
    const commonData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'common.json'), 'utf8'));
    res.render('movie', { movie: rows[0], common: commonData });
});

app.get('/movieEdit', async (req, res) => {
    const id = req.query.id;
    const rows = await db.query('SELECT * FROM film WHERE film_id = ?', [id]);
    const commonData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'common.json'), 'utf8'));
    res.render('movieEdit', { movie: rows[0], common: commonData });
});

app.get('/movieAdd', (req, res) => {
    const commonData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'common.json'), 'utf8'));
    res.render('movieAdd', { common: commonData });
});

// --- RUTES POST ---

app.post('/afegirPeli', async (req, res) => {
    try {
        const { title, description, release_year, language_id } = req.body;
        const sql = `INSERT INTO film (title, description, release_year, language_id) VALUES (?, ?, ?, ?)`;
        await db.query(sql, [title, description, release_year, language_id]);
        res.redirect('/movies');
    } catch (err) {
        res.status(500).send("Error al afegir");
    }
});

app.post('/editarPeli', async (req, res) => {
    try {
        const { film_id, title, description, release_year } = req.body;
        const sql = `UPDATE film SET title = ?, description = ?, release_year = ? WHERE film_id = ?`;
        await db.query(sql, [title, description, release_year, film_id]);
        res.redirect(`/movie?id=${film_id}`); 
    } catch (err) {
        res.status(500).send("Error al editar");
    }
});

app.post('/esborrarPeli', async (req, res) => {
    try {
        const { film_id } = req.body;
        await db.query(`DELETE FROM film WHERE film_id = ?`, [film_id]);
        res.redirect('/movies');
    } catch (err) {
        res.status(500).send("Error: No es pot esborrar una peli amb relacions actives.");
    }
});

// Start server
const httpServer = app.listen(port, () => {
  console.log(`Servidor funcionant a http://localhost:${port}/`);
});

process.on('SIGINT', () => {
  httpServer.close();
  process.exit(0);
});